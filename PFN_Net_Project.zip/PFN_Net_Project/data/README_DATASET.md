# Dataset Details

## Multi-Platform Social Sentiment Evolution

The public dataset identified for this project is **Multi-Platform Social Sentiment Evolution**. A public research repository reports that the CSV contains **150,000 posts, 31 raw attributes, and six platforms: Facebook, Instagram, Reddit, TikTok, Twitter/X, and YouTube**.

Public source:

https://www.kaggle.com/datasets/sohumgokhale/multi-platform-social-sentiment-evolution

Repository describing the dataset:

https://github.com/ThienY173/FDSE_2026_A_comparative_study_across_six_platforms

## Federated client mapping used by this paper

| Client | Platform |
|---|---|
| Client 1 | YouTube |
| Client 2 | Instagram |
| Client 3 | Facebook |
| Client 4 | Reddit |

TikTok and Twitter/X are excluded from the main experiment if the manuscript is specifically restricted to four platforms.

## Likely information groups

The dataset documentation and public analyses identify platform identifiers, timestamps/date information, sentiment-related fields and engagement information such as likes/comments/shares/views/total engagement. Exact column names should always be read from the downloaded CSV rather than assumed.

Run:

```bash
python src/inspect_dataset.py --csv data/multi_platform_social_sentiment_evolution.csv
```

to print the exact schema, data types, missing values, platform counts and candidate columns.

## Visual modality

The named public CSV should not be treated as a verified image dataset. The project therefore supports ViT conditionally. To run the complete BERT+ViT+TCN pipeline, provide an `image_path` column and corresponding licensed local images. Otherwise, set `model.use_images: false` and report the experiment as text+behavior rather than claiming a complete visual modality.

## Target construction

If a ready-made six-class sentiment-engagement label exists, the loader uses it. Otherwise, the code can construct an engagement-aware target from sentiment plus engagement level only when suitable sentiment and engagement fields are available. The exact construction is recorded in `outputs/schema.json`.

Do not silently create labels from unavailable fields.
