import argparse, json, pandas as pd
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--csv',required=True); a=p.parse_args()
df=pd.read_csv(a.csv)
print('\n=== DATASET OVERVIEW ===')
print('Rows:',len(df)); print('Columns:',len(df.columns)); print('\nColumns:'); print(list(df.columns))
print('\nDtypes:'); print(df.dtypes.to_string())
print('\nMissing values:'); print(df.isna().sum().sort_values(ascending=False).head(30).to_string())
for c in df.columns:
    if 'platform' in c.lower():
        print('\nPlatform counts for',c); print(df[c].astype(str).value_counts().to_string())
        break
Path('outputs').mkdir(exist_ok=True)
json.dump({'rows':len(df),'columns':len(df.columns),'column_names':list(df.columns)},open('outputs/raw_schema.json','w'),indent=2)
