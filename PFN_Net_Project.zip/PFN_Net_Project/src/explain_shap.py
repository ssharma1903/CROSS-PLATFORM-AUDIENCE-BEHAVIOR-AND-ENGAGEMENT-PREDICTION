import argparse, yaml, torch, numpy as np
from transformers import AutoTokenizer, AutoImageProcessor
from dataset import load_and_prepare, SocialDataset
from models import PFNFull

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--checkpoint',required=True); ap.add_argument('--csv',required=True); ap.add_argument('--config',default='configs/config.yaml'); args=ap.parse_args()
    import shap
    cfg=yaml.safe_load(open(args.config)); df,meta,le=load_and_prepare(args.csv,cfg)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tok=AutoTokenizer.from_pretrained(cfg['model']['text_model']); img=AutoImageProcessor.from_pretrained(cfg['model']['image_model']) if cfg['model'].get('use_images',True) else None
    model=PFNFull(cfg).to(device); model.load_state_dict(torch.load(args.checkpoint,map_location=device)); model.eval()
    ds=SocialDataset(df,tok,img,cfg['training']['sequence_length'],cfg['model'].get('use_images',True))
    n=min(32,len(ds)); X=[]
    with torch.no_grad():
        for i in range(n):
            X.append(ds[i]['behavior'].mean(0).numpy())
    X=np.stack(X)
    # Explain a lightweight proxy around the behavioral input; multimodal raw-feature SHAP needs a modality-specific wrapper.
    background=torch.tensor(X[:min(8,n)],dtype=torch.float32,device=device)
    def f(x):
        # Keep the trained model fixed; replace behavior sequence while using one reference text/image sample.
        outs=[]
        ref=ds[0]
        for row in x:
            b=torch.tensor(np.tile(row,(cfg['training']['sequence_length'],1))[None],dtype=torch.float32,device=device)
            ids=ref['input_ids'][None].to(device); mask=ref['attention_mask'][None].to(device)
            pix=ref.get('pixel_values'); pix=pix[None].to(device) if pix is not None else None
            with torch.no_grad(): outs.append(torch.softmax(model(ids,mask,b,pix)[0],-1).cpu().numpy()[0])
        return np.stack(outs)
    explainer=shap.KernelExplainer(f,background.cpu().numpy()); sv=explainer.shap_values(X[:min(16,n)],nsamples=50)
    np.save('outputs/shap_values.npy',np.asarray(sv,dtype=object),allow_pickle=True); print('Saved outputs/shap_values.npy')
if __name__=='__main__': main()
