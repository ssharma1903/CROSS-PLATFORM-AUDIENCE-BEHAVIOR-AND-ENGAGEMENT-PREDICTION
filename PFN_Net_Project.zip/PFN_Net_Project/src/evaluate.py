import argparse, os, yaml, torch, numpy as np
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, AutoImageProcessor
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, mean_absolute_error, mean_squared_error, r2_score
from dataset import load_and_prepare, SocialDataset
from models import PFNFull

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--checkpoint',required=True); ap.add_argument('--csv',required=True); ap.add_argument('--config',default='configs/config.yaml'); args=ap.parse_args()
    cfg=yaml.safe_load(open(args.config)); df,meta,le=load_and_prepare(args.csv,cfg)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tok=AutoTokenizer.from_pretrained(cfg['model']['text_model']); img=AutoImageProcessor.from_pretrained(cfg['model']['image_model']) if cfg['model'].get('use_images',True) else None
    model=PFNFull(cfg).to(device); model.load_state_dict(torch.load(args.checkpoint,map_location=device)); model.eval()
    ds=SocialDataset(df,tok,img,cfg['training']['sequence_length'],cfg['model'].get('use_images',True)); dl=DataLoader(ds,batch_size=cfg['training']['batch_size'])
    y=[]; p=[]
    with torch.no_grad():
        for b in dl:
            kw={k:v.to(device) for k,v in b.items() if k in {'input_ids','attention_mask','behavior','pixel_values'}}
            if 'pixel_values' not in kw: kw['pixel_values']=None
            logits,_,_,_=model(**kw); p.extend(logits.argmax(1).cpu().numpy()); y.extend(b['label'].numpy())
    pr,re,f1,_=precision_recall_fscore_support(y,p,average='weighted',zero_division=0)
    out={'accuracy':accuracy_score(y,p),'precision':pr,'recall':re,'f1':f1,'mae':mean_absolute_error(y,p),'rmse':mean_squared_error(y,p)**0.5,'r2':r2_score(y,p),'parameters':sum(x.numel() for x in model.parameters())}
    os.makedirs(cfg['output_dir'],exist_ok=True); import json; json.dump(out,open(os.path.join(cfg['output_dir'],'metrics.json'),'w'),indent=2); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
