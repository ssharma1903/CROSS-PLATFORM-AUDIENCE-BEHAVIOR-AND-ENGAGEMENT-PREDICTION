import torch

def protect_update(delta, clip_norm=1.0, noise_multiplier=0.5):
    sq = torch.sqrt(sum((v.detach()**2).sum() for v in delta.values()))
    scale = min(1.0, float(clip_norm / (sq.item() + 1e-12)))
    out = {}
    for k,v in delta.items():
        clipped = v.detach() * scale
        noise = torch.randn_like(clipped) * (noise_multiplier * clip_norm)
        out[k] = clipped + noise
    return out, {'global_norm': sq.item(), 'clip_scale': scale, 'noise_multiplier': noise_multiplier}
