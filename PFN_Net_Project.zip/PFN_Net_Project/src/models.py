import torch
import torch.nn as nn
from transformers import AutoModel, AutoImageProcessor, ViTModel


class TCN(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_dim, 64, 3, padding=2, dilation=1), nn.ReLU(),
            nn.Conv1d(64, out_dim, 3, padding=4, dilation=2), nn.ReLU()
        )
    def forward(self, x):
        return self.net(x.transpose(1,2)).transpose(1,2).mean(1)


class FBAM(nn.Module):
    def __init__(self, text_dim, image_dim, behavior_dim, latent_dim):
        super().__init__()
        self.t = nn.Linear(text_dim, latent_dim)
        self.v = nn.Linear(image_dim, latent_dim)
        self.b = nn.Linear(behavior_dim, latent_dim)
        self.norm = nn.LayerNorm(latent_dim)
    def forward(self, t, v, b):
        zt, zv, zb = self.t(t), self.v(v), self.b(b)
        return self.norm(zt + zv + zb), (zt, zv, zb)


class PFNNet(nn.Module):
    def __init__(self, latent_dim=128, cnn_channels=64, heads=4, layers=1, dropout=0.1, num_classes=6):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(1, cnn_channels, 3, padding=1), nn.ReLU(),
            nn.Conv1d(cnn_channels, cnn_channels, 3, padding=1), nn.ReLU()
        )
        enc = nn.TransformerEncoderLayer(d_model=cnn_channels, nhead=heads, batch_first=True,
                                         dropout=dropout, dim_feedforward=cnn_channels*2, activation='gelu')
        self.transformer = nn.TransformerEncoder(enc, num_layers=layers)
        self.fc = nn.Linear(cnn_channels, num_classes)
    def forward(self, h):
        x = self.cnn(h.unsqueeze(1)).transpose(1,2)
        x = self.transformer(x).mean(1)
        return self.fc(x), x


class PFNFull(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        m = cfg['model']
        self.text_encoder = AutoModel.from_pretrained(m['text_model'])
        self.image_encoder = ViTModel.from_pretrained(m['image_model']) if m.get('use_images', True) else None
        self.tcn = TCN(m['behavior_dim'], m['behavior_dim'])
        self.fbam = FBAM(m['text_dim'], m['image_dim'], m['behavior_dim'], m['latent_dim'])
        self.pfn = PFNNet(m['latent_dim'], m['cnn_channels'], m['transformer_heads'], m['transformer_layers'], m['dropout'], m['num_classes'])

    def forward(self, input_ids, attention_mask, behavior, pixel_values=None):
        t = self.text_encoder(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state[:,0]
        if self.image_encoder is not None and pixel_values is not None:
            v = self.image_encoder(pixel_values=pixel_values).last_hidden_state[:,0]
        else:
            v = torch.zeros(t.size(0), self.fbam.v.in_features, device=t.device)
        b = self.tcn(behavior)
        h, parts = self.fbam(t,v,b)
        logits, hidden = self.pfn(h)
        return logits, hidden, h, parts
