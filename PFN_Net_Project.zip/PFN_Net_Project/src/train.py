import argparse, os, random, json, copy
import numpy as np, torch, yaml
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, AutoImageProcessor
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, mean_absolute_error, mean_squared_error, r2_score
from dataset import load_and_prepare, SocialDataset
from models import PFNFull
from privacy import protect_update
from federated import get_state_delta, harmonize, fedavg, apply_delta

def seed_all(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)

def local_train(global_model, frame, cfg, device, tokenizer, image_processor):
    local = copy.deepcopy(global_model).to(device)
    ds = SocialDataset(frame, tokenizer, image_processor, cfg['training']['sequence_length'], cfg['model'].get('use_images',True))
    dl = DataLoader(ds,batch_size=cfg['training']['batch_size'],shuffle=True)
    opt = torch.optim.AdamW(local.parameters(),lr=cfg['training']['lr'])
    ce = torch.nn.CrossEntropyLoss()
    local.train()
    for _ in range(cfg['training']['local_epochs']):
        for batch in dl:
            opt.zero_grad(set_to_none=True)
            kw={k:v.to(device) for k,v in batch.items() if k in {'input_ids','attention_mask','behavior','pixel_values'}}
            if 'pixel_values' not in kw: kw['pixel_values']=None
            logits,_,_,_=local(**kw)
            loss=ce(logits,batch['label'].to(device)); loss.backward(); torch.nn.utils.clip_grad_norm_(local.parameters(),1.0); opt.step()
    delta=get_state_delta(global_model,local)
    protected, stats=protect_update(delta,cfg['privacy']['clip_norm'],cfg['privacy']['noise_multiplier'])
    return protected,len(ds),stats

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='configs/config.yaml'); args=ap.parse_args()
    cfg=yaml.safe_load(open(args.config)); seed_all(cfg['seed']); os.makedirs(cfg['output_dir'],exist_ok=True)
    df,meta,le=load_and_prepare(cfg['csv_path'],cfg)
    clients=[]
    for p in cfg['clients']:
        f=df[df[meta['platform_column']].astype(str).str.lower()==p.lower()].copy()
        if cfg['training']['max_rows_per_client'] and len(f)>cfg['training']['max_rows_per_client']:
            f=f.sample(cfg['training']['max_rows_per_client'],random_state=cfg['seed'])
        if len(f): clients.append((p,f))
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tok=AutoTokenizer.from_pretrained(cfg['model']['text_model'])
    img=AutoImageProcessor.from_pretrained(cfg['model']['image_model']) if cfg['model'].get('use_images',True) else None
    global_model=PFNFull(cfg).to(device)
    history=[]
    for rnd in range(cfg['training']['rounds']):
        ds=[]; weights=[]; privacy_stats=[]
        for name,frame in clients:
            d,n,ps=local_train(global_model,frame,cfg,device,tok,img); ds.append(d); weights.append(n); privacy_stats.append({'client':name,**ps})
        ds=harmonize(ds,cfg['federation']['harmonization_strength'])
        agg=fedavg(ds,weights); apply_delta(global_model,agg)
        history.append({'round':rnd+1,'clients':[x[0] for x in clients],'weights':weights,'privacy':privacy_stats})
        print('Round',rnd+1,'complete')
    torch.save(global_model.state_dict(),os.path.join(cfg['output_dir'],'global_pfn_net.pt'))
    json.dump({'dataset':meta,'classes':list(le.classes_),'device':str(device),'history':history},open(os.path.join(cfg['output_dir'],'training_summary.json'),'w'),indent=2,default=str)
    print('Saved outputs/global_pfn_net.pt')
if __name__=='__main__': main()
