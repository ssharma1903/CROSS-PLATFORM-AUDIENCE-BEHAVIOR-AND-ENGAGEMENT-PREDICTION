import copy
import torch

def get_state_delta(global_model, local_model):
    g = global_model.state_dict(); l = local_model.state_dict()
    return {k: l[k].detach().cpu() - g[k].detach().cpu() for k in g}

def apply_delta(model, delta, strength=1.0):
    state = model.state_dict()
    for k,v in delta.items(): state[k] = state[k] + strength*v.to(state[k].device)
    model.load_state_dict(state)

def harmonize(deltas, strength=0.1):
    if len(deltas) < 2: return deltas
    mean = {k: sum(d[k] for d in deltas)/len(deltas) for k in deltas[0]}
    return [{k: (1-strength)*d[k] + strength*mean[k] for k in d} for d in deltas]

def fedavg(deltas, weights):
    total = sum(weights)
    keys = deltas[0].keys()
    return {k: sum(d[k]*(w/total) for d,w in zip(deltas,weights)) for k in keys}
