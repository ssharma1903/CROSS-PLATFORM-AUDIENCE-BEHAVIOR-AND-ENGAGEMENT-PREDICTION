import os, re, json
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from sklearn.preprocessing import MinMaxScaler, LabelEncoder


def pick_column(df, candidates):
    lower = {c.lower(): c for c in df.columns}
    for c in candidates:
        if c.lower() in lower:
            return lower[c.lower()]
    for c in df.columns:
        lc = c.lower()
        if any(x.lower() in lc for x in candidates):
            return c
    return None


def load_and_prepare(csv_path, cfg):
    df = pd.read_csv(csv_path)
    cols = cfg['columns']
    platform_col = pick_column(df, [cols['platform']])
    if platform_col is None:
        raise ValueError('No platform column found.')
    text_col = pick_column(df, cols['text_candidates'])
    time_col = pick_column(df, cols['time_candidates'])
    image_col = pick_column(df, cols['image_candidates'])
    target_col = pick_column(df, cols['target_candidates'])
    engagement_cols = [pick_column(df, [x]) for x in cols['engagement_candidates']]
    engagement_cols = [x for x in engagement_cols if x is not None]

    df[platform_col] = df[platform_col].astype(str)
    df['_text'] = df[text_col].fillna('').astype(str) if text_col else ''
    df['_time'] = pd.to_datetime(df[time_col], errors='coerce') if time_col else pd.NaT
    df['_image'] = df[image_col].fillna('').astype(str) if image_col else ''

    # Prefer an existing target. Otherwise create a six-class target only when sentiment + engagement are available.
    if target_col:
        df['_target_raw'] = df[target_col]
    else:
        sentiment_col = pick_column(df, ['sentiment', 'sentiment_label', 'sentiment_class', 'sentiment_positive'])
        if sentiment_col is None or not engagement_cols:
            raise ValueError('No target found. Add a target column or provide sentiment + engagement columns for target construction.')
        engagement = pd.to_numeric(df[engagement_cols], errors='coerce').fillna(0).sum(axis=1)
        q = engagement.quantile(0.70)
        high = engagement >= q
        s = df[sentiment_col].astype(str).str.lower()
        def map_sent(x):
            if 'pos' in x or x in {'1','positive'}: return 'Positive'
            if 'neg' in x or x in {'-1','negative'}: return 'Negative'
            return 'Neutral'
        sl = s.map(map_sent)
        df['_target_raw'] = sl + '-' + np.where(high, 'High', 'Low')

    # Encode target consistently.
    le = LabelEncoder()
    df['_target'] = le.fit_transform(df['_target_raw'].astype(str))

    # Behavioral features: engagement columns + useful numeric columns, excluding target.
    numeric = df.select_dtypes(include=[np.number]).columns.tolist()
    excluded = {'_target'}
    behavior_cols = list(dict.fromkeys(engagement_cols + [c for c in numeric if c not in excluded]))
    behavior_cols = behavior_cols[:32]
    if not behavior_cols:
        raise ValueError('No numerical behavioral features were found.')
    Xb = df[behavior_cols].apply(pd.to_numeric, errors='coerce').fillna(0.0).values
    scaler = MinMaxScaler()
    df['_behavior_vector'] = list(scaler.fit_transform(Xb).astype('float32'))

    meta = {
        'rows': len(df), 'columns': len(df.columns), 'platform_column': platform_col,
        'text_column': text_col, 'time_column': time_col, 'image_column': image_col,
        'target_column': target_col, 'behavior_columns': behavior_cols,
        'classes': list(le.classes_), 'platform_counts': df[platform_col].value_counts().to_dict()
    }
    os.makedirs('outputs', exist_ok=True)
    with open('outputs/schema.json','w') as f: json.dump(meta,f,indent=2,default=str)
    return df, meta, le


class SocialDataset(Dataset):
    def __init__(self, frame, tokenizer, image_processor=None, sequence_length=8, use_images=False):
        self.df = frame.reset_index(drop=True)
        self.tokenizer = tokenizer
        self.image_processor = image_processor
        self.sequence_length = sequence_length
        self.use_images = use_images

    def __len__(self): return len(self.df)

    def __getitem__(self, idx):
        r = self.df.iloc[idx]
        tok = self.tokenizer(str(r['_text']), truncation=True, padding='max_length', max_length=96, return_tensors='pt')
        item = {k:v.squeeze(0) for k,v in tok.items()}
        b = np.asarray(r['_behavior_vector'], dtype=np.float32)
        # Repeat a point feature vector as a short sequence for the TCN.
        item['behavior'] = torch.tensor(np.tile(b, (self.sequence_length,1)), dtype=torch.float32)
        item['label'] = torch.tensor(int(r['_target']), dtype=torch.long)
        item['has_image'] = torch.tensor(0, dtype=torch.long)
        if self.use_images and self.image_processor is not None and str(r['_image']):
            p = str(r['_image'])
            if not os.path.isabs(p): p = os.path.join('data', p)
            if os.path.exists(p):
                from PIL import Image
                image = Image.open(p).convert('RGB')
                item['pixel_values'] = self.image_processor(images=image, return_tensors='pt')['pixel_values'].squeeze(0)
                item['has_image'] = torch.tensor(1, dtype=torch.long)
        return item
