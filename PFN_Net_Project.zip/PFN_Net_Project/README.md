# PFN-Net: Privacy-Preserving Multimodal Federated Learning

Reproducible Python implementation skeleton for:

**Privacy-Preserving Multimodal Federated Learning for Cross-Platform Audience Behavior and Engagement Prediction**

## Pipeline

CSV dataset -> preprocessing -> BERT text features + optional ViT image features + TCN behavioral features -> FBAM fusion/alignment -> lightweight CNN-Transformer PFN-Net -> local update -> PAGS privacy protection -> CPEHM harmonisation -> FedAvg aggregation -> evaluation + SHAP.

## Dataset

Primary dataset: **Multi-Platform Social Sentiment Evolution**.

Public source reported by the dataset repository:
- Kaggle: https://www.kaggle.com/datasets/sohumgokhale/multi-platform-social-sentiment-evolution
- Public code/data repository: https://github.com/ThienY173/FDSE_2026_A_comparative_study_across_six_platforms

Reported dataset characteristics: 150,000 social-media posts and 31 raw attributes across six platforms (Facebook, Instagram, Reddit, TikTok, Twitter/X, YouTube). The present PFN-Net experiment can restrict the federated clients to **YouTube, Instagram, Facebook and Reddit** to match the paper design.

### Important multimodal-data note

The public CSV is primarily structured/text/social-metadata data. It does not by itself guarantee a corresponding image file for every post. Therefore this implementation does **not fabricate visual data**. ViT is activated only when an `image_path` column or image directory is supplied. Without images, the visual branch is disabled and the experiment is explicitly reported as text+behavior rather than full multimodal learning.

## Expected CSV columns

The loader searches flexibly for these fields:

- `platform` - client/platform identifier
- `text`, `content`, `caption`, `post_text`, or similar - text input
- `date`, `timestamp`, or `time` - temporal field
- engagement fields such as `likes`, `comments`, `shares`, `views`, `total_engagement`
- optional `image_path` - local image path for ViT
- optional target such as `engagement_class`, `target`, or `label`

If your exact CSV uses different names, edit `configs/config.yaml`.

## Environment

Recommended:

- Python 3.10+
- PyTorch 2.x
- Transformers 4.x
- torchvision
- pandas, numpy, scikit-learn
- scipy, matplotlib, seaborn
- shap
- tqdm
- pyyaml

Install:

```bash
pip install -r requirements.txt
```

## Data setup

1. Download the CSV from the public Kaggle source.
2. Place it at:

```text
data/multi_platform_social_sentiment_evolution.csv
```

3. If using images, place them under `data/images/` and provide an `image_path` column containing paths relative to `data/`.

Do not place private audience records into the repository.

## Run

### 1. Inspect dataset

```bash
python src/inspect_dataset.py --csv data/multi_platform_social_sentiment_evolution.csv
```

### 2. Train PFN-Net

```bash
python src/train.py --config configs/config.yaml
```

### 3. Evaluate

```bash
python src/evaluate.py --checkpoint outputs/global_pfn_net.pt --csv data/multi_platform_social_sentiment_evolution.csv
```

### 4. SHAP explanation

```bash
python src/explain_shap.py --checkpoint outputs/global_pfn_net.pt --csv data/multi_platform_social_sentiment_evolution.csv
```

## Federated design

Each platform is treated as a client. Raw rows remain local to the client-specific dataframe during training. Only protected parameter updates are aggregated.

1. BERT encodes text.
2. Optional ViT encodes images.
3. TCN encodes temporal behavioral sequences.
4. FBAM projects all modalities to a shared latent dimension, fuses them, and aligns client representations using a shared prototype.
5. PFN-Net uses a lightweight 1-D CNN followed by a compact Transformer encoder.
6. PAGS clips local updates and adds Gaussian perturbation.
7. CPEHM harmonizes protected updates before aggregation.
8. FedAvg creates the global model.
9. SHAP explains the final prediction using the available feature representation.

## Privacy disclaimer

PAGS in this research implementation is a configurable differential-privacy-inspired update perturbation mechanism. A formal privacy guarantee requires a complete privacy accountant, composition analysis, threat model, clipping policy, and declared epsilon/delta protocol. The code therefore reports the configured noise parameters and must not be described as a formally certified privacy guarantee unless those components are separately validated.

## Reproducing the paper's reported numbers

The manuscript reports 99.8% accuracy, 13.7 ms inference latency, 8.6M parameters, 43.8 MB communication overhead and privacy budget 1.20. These are manuscript-reported values, not values hard-coded into the implementation. The supplied code computes metrics from the actual run and writes them to `outputs/metrics.json`.

A result should be reported as reproduced only when the same dataset version, preprocessing, split, random seeds, hardware, hyperparameters and evaluation protocol are used.

## Project structure

```text
PFN_Net_Project/
├── README.md
├── requirements.txt
├── configs/
│   └── config.yaml
├── data/
│   └── README_DATASET.md
├── docs/
│   └── METHODOLOGY.md
├── src/
│   ├── inspect_dataset.py
│   ├── dataset.py
│   ├── models.py
│   ├── privacy.py
│   ├── federated.py
│   ├── train.py
│   ├── evaluate.py
│   └── explain_shap.py
└── outputs/
```

## Ethical and data-use note

Use only data for which you have permission and which complies with the source platform's terms, the dataset license, institutional requirements, and applicable privacy law. Do not attempt to reconstruct individual identities from model updates.
