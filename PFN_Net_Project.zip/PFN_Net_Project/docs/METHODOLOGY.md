# PFN-Net Implementation Mapping

## Stage 1: Local preprocessing
Text is cleaned and tokenized for BERT. Numerical engagement variables are scaled using training-set statistics. Images are resized through the ViT processor when image files are available.

## Stage 2: Multimodal feature extraction
- BERT -> contextual text representation.
- ViT -> optional visual representation.
- TCN -> temporal behavioral representation.

## Stage 3: FBAM
Each modality is projected to the same latent dimension. The projected vectors are fused by addition. A shared prototype is calculated across participating clients and a prototype-distance penalty is added to the local objective. This avoids the O(K^2) cost of all-pairs alignment.

## Stage 4: PFN-Net
The fused representation is reshaped as a short feature sequence, processed by a 1-D CNN and then a compact Transformer encoder. Mean pooling gives the local representation and a linear layer produces the engagement/sentiment class.

## Stage 5: PAGS
The local parameter delta is clipped and Gaussian noise is added. The resulting protected delta is sent for aggregation.

## Stage 6: CPEHM
Protected client updates are scaled toward a common mean update using a configurable harmonisation strength before FedAvg.

## Stage 7: Global model
Weighted FedAvg aggregates client updates by local sample count.

## Stage 8: Explanation
SHAP is applied to the compact model input representation. For a publication-grade explanation of original text/image/behavior features, an additional modality-specific attribution layer should be implemented.
